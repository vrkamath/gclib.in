from django.db import models

# Create your models here.
class bca(models.Model):
    name=models.CharField(max_length=32)
    rollnumber=models.IntegerField()
    batch=models.CharField(max_length=32)
    issuebooks=models.IntegerField()
    fine=models.IntegerField(null=True)

class bcom(models.Model):
    name=models.CharField(max_length=32)
    rollnumber=models.IntegerField()
    batch=models.CharField(max_length=32)
    issuebooks=models.IntegerField()
    fine=models.IntegerField(null=True)

class bba(models.Model):
    name=models.CharField(max_length=32)
    rollnumber=models.IntegerField()
    batch=models.CharField(max_length=32)
    issuebooks=models.IntegerField()
    fine=models.IntegerField(null=True)

class mcom(models.Model):
    name=models.CharField(max_length=32)
    rollnumber=models.IntegerField()
    batch=models.CharField(max_length=32)
    issuebooks=models.IntegerField()
    fine=models.IntegerField(null=True)
class teachers(models.Model):
    stnumber=models.CharField(max_length=11)
    name=models.CharField(max_length=32)
    department=models.CharField(max_length=32)
    issuebooks=models.IntegerField()
class login(models.Model):
    username=models.CharField(max_length=16)
    password=models.CharField(max_length=16)
class books(models.Model):
    date=models.CharField(max_length=12)
    accno=models.IntegerField()
    ddcno=models.CharField(max_length=32)
    title=models.CharField(max_length=32)
    author=models.CharField(max_length=32)
    publisher=models.CharField(max_length=32)
    year=models.CharField(max_length=32)
    edition=models.CharField(max_length=32)
    numberpages=models.CharField(max_length=32)
    price=models.IntegerField()
    issued=models.CharField(max_length=32)
    issuemember=models.CharField(max_length=32)
class studentissue(models.Model):
    accno=models.IntegerField()
    title=models.CharField(max_length=32)
    author=models.CharField(max_length=32)
    edition=models.CharField(max_length=32)
    studentname=models.CharField(max_length=32)
    rollnumber=models.IntegerField()
    batch=models.CharField(max_length=32)
    department=models.CharField(max_length=32)
    issuedate=models.DateField()
    duedate=models.DateField()
    returndate=models.DateField(null=True)
    flag=models.CharField(max_length=1)
class teacherissue(models.Model):
    accno=models.IntegerField()
    title=models.CharField(max_length=32)
    author=models.CharField(max_length=32)
    edition=models.CharField(max_length=32)
    teachername=models.CharField(max_length=32)
    staffnumber=models.CharField(max_length=11)
    department=models.CharField(max_length=32)
    issuedate=models.DateField()
    returndate=models.DateField(null=True)
    flag=models.CharField(max_length=1)
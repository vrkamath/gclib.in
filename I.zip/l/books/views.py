from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import AnonymousUser
from books.models import login,bba,bcom,bca,teachers,books,mcom,studentissue,teacherissue
from django.http import HttpResponse
from datetime import *
from tkinter import messagebox



# Create your views here.
def log(request):
    return render(request,'login.html')
def logout(request):
    request.session.flush()
    if hasattr(request,'user'):
        request.user=AnonymousUser()
        return render(request,'login.html')

def register(request):
    return render(request,'register.html')
def editregister(request):
    return render(request,'editregister.html')
def book(request):
    return render(request,'adbok.html')
def bulklist(request):
    return render(request,'bulklist.html')
def blist(request):
    return render(request,'blist.html')
def delet(request):
    return render(request,'delete.html')
def home(request):
    a=books.objects.all().count()
    b=bca.objects.all().count()
    c=bba.objects.all().count()
    d=bcom.objects.all().count()
    e=mcom.objects.all().count()
    al=b+c+d+e
    t=teachers.objects.all().count()
    return render(request,'home.html',{'l':a,'s':al,'h':t})
def isret(request):
    return render(request,'isretmain.html')
def isue(request):
    return render(request,'issue.html') 
def logi(request):
    if(request.method == 'POST'):
        username = request.POST.get("username")
        password = request.POST.get("password")
        t=login.objects.all()
        d=0
        for i in t: 
            if(i.username == username and i.password == password):
                d=1
                return redirect('/home/')
        if(d == 0):
            return HttpResponse('invalid cerdinals')             
def regi(request):
    if(request.method == 'POST'):
        department=request.POST.get("department")
        if(department == 'BCOM'):
            y=bcom()
            y.name=request.POST.get("name").upper()
            y.rollnumber=request.POST.get("rollnumber")            
            y.batch=request.POST.get("batch")
            y.issuebooks=0
            y.save()
        elif(department == 'BCA'):
            y=bca()
            y.name=request.POST.get("name").upper()
            y.rollnumber=request.POST.get("rollnumber")            
            y.batch=request.POST.get("batch")
            y.issuebooks=0
            y.save()
        elif(department == 'BBA'):
            y=bba()
            y.name=request.POST.get("name").upper()
            y.rollnumber=request.POST.get("rollnumber")            
            y.batch=request.POST.get("batch")
            y.issuebooks=0
            y.save()
        elif(department == 'MCOM'):
            y=mcom()
            y.name=request.POST.get("name").upper()
            y.rollnumber=request.POST.get("rollnumber")            
            y.batch=request.POST.get("batch")
            y.issuebooks=0
            y.save()
    return redirect('/reg/')
def editregi(request,id):
    if(request.method == 'POST'):
        department=request.POST.get("department")
        if(department == 'BCOM'):
            y=bcom.objects.get(id=id)
            y.name=request.POST.get("name").upper()
            y.rollnumber=request.POST.get("rollnumber")            
            y.batch=request.POST.get("batch")
            y.save()
            return redirect('/bcomlist/')
        elif(department == 'BCA'):
            y=bca.objects.get(id=id)
            y.name=request.POST.get("name").upper()
            y.rollnumber=request.POST.get("rollnumber")            
            y.batch=request.POST.get("batch")
            y.save()
            return redirect('/bcalist/')
        elif(department == 'BBA'):
            y=bba.objects.get(id=id)
            y.name=request.POST.get("name").upper()
            y.rollnumber=request.POST.get("rollnumber")            
            y.batch=request.POST.get("batch")
            y.save()
            return redirect('/bbalist/')
        elif(department == 'MCOM'):
            y=mcom.objects.get(id=id)
            y.name=request.POST.get("name").upper()
            y.rollnumber=request.POST.get("rollnumber")            
            y.batch=request.POST.get("batch")
            y.save()
            return redirect('/mcomlist/')
    
def tregi(request):
    if(request.method == 'POST'):
        y=teachers()
        y.name=request.POST.get("name").upper()
        y.stnumber=request.POST.get("stnumber")
        y.department=request.POST.get("department")            
        y.issuebooks=0
        y.save() 
    return redirect('/reg/') 
def teditregi(request,id):
    if(request.method == 'POST'):
        y=teachers.objects.get(id=id)
        y.name=request.POST.get("name").upper()
        y.stnumber=request.POST.get("stnumber")
        y.department=request.POST.get("department")            
        y.save() 
    return redirect('/teachlist/')      
def add(request):
    if(request.method == 'POST'):
        accno=request.POST.get("accno")
        title=request.POST.get("title")
        d=0
        b=books.objects.all()
        for i in b:
            if(i.accno == accno):
                d=1
                return render(request, 'booksalert.html')
        if(d == 0):
            a=books()
            a.date=request.POST.get("date")
            a.accno=request.POST.get("accno")
            a.ddcno=request.POST.get("ddcno")
            title=request.POST.get("title")
            a.title=title.upper()
            a.author=request.POST.get("author").upper()
            a.publisher=request.POST.get("publisher").upper()
            a.year=request.POST.get("year")
            a.edition=request.POST.get("edition").upper()
            a.numberpages=request.POST.get("numberpages")
            a.price=request.POST.get("price")
            a.issued='AVILABLE'
            a.issuemember='NULL'
            a.save()
        else:
             return render(request, 'booksalert.html')

            
    return redirect('/books/')
def list(request):
    a=books.objects.all().count()
    b=bca.objects.all().count()
    c=bba.objects.all().count()
    d=bcom.objects.all().count()
    e=mcom.objects.all().count()
    t=teachers.objects.all().count()
    f=b+c+d+e+t
    return render(request,'list.html',{'bk':a,'to':f})
def bookl(request):
    a=books.objects.all().count()
    b1=studentissue.objects.all()
    p=0 
    e=0
    for i in b1:
        if(i.flag == '0'):
            p=p+1
    b2=teacherissue.objects.all()
    q=0
    f=0
    for i in b2:
        if(i.flag == '0'):
            q=q+1
    d=q+p
    j=0
    b=books.objects.all()
    for i in b:
        if(i.issued == 'AVILABLE'):
            j=j+1
    return render(request,'booksl.html',{'bk':a,'ik':d,'rk':j})
def left(request):
    a=books.objects.all()
    return render(request,'left.html',{'h':a})
def isul(request):
    c=books.objects.all()
    return render(request,'isul.html',{'bo':c})
def isviewp(request,accno):
    k=books.objects.get(accno = accno)
    if(k.issuemember == 'studentissue'):
        h=studentissue.objects.get(accno=k.accno,flag='0')
    else:
        h=teacherissue.objects.get(accno=k.accno,flag='0')
    return render(request,'isview.html',{'a':h})
def members(request):
    a=books.objects.all().count()
    b=bca.objects.all().count()
    c=bba.objects.all().count()
    d=bcom.objects.all().count()
    e=mcom.objects.all().count()
    t=teachers.objects.all().count()
    return render(request,'members.html',{'bk':a,'bc':b,'bb':c,'bo':d,'mo':e,'te':t})
def booklist(request):
    h=books.objects.all()
    return render(request,'booklist.html',{'a':h})
def teachlist(request):
    h=teachers.objects.all()
    return render(request,'teachlist.html',{'a':h})
def bcalist(request):
    h=bca.objects.all()
    return render(request,'bcalist.html',{'a':h})
def bbalist(request):
    h=bba.objects.all()
    return render(request,'bbalist.html',{'a':h})
def bcomlist(request):
    h=bcom.objects.all()
    return render(request,'bcomlist.html',{'a':h})
def mcomlist(request):
    h=mcom.objects.all()
    return render(request,'mcomlist.html',{'a':h})
def view(request,id):
    k=books.objects.get(id=id)
    return render(request,'details.html',{'a':k})
def ed(request,id):
    k=books.objects.get(id=id)
    return render(request,'edit.html',{'a':k})
def edit(request,id):
    if(request.method == 'POST'):
        a=books.objects.get(id=id)
        a.date=request.POST.get("date")
        a.accno=request.POST.get("accno")
        a.ddcno=request.POST.get("ddcno")
        title=request.POST.get("title")
        a.title=title.upper()
        a.author=request.POST.get("author")
        a.publisher=request.POST.get("publisher")
        a.year=request.POST.get("year")
        a.edition=request.POST.get("edition")
        a.numberpages=request.POST.get("numberpages")
        a.price=request.POST.get("price")
        a.issued='AVILABLE'
        a.save()
    h=books.objects.all()
    return redirect('/list/')
def delete(request,id):
    k=books.objects.get(id=id)
    k.delete()
    return redirect('/list/')
def bcview(request,id):
    j=studentissue.objects.all()
    k=bca.objects.get(id=id)
    return render(request,'sdetails.html',{'a':k,'b':'BCA','c':j})
def bced(request,id):
    k=bca.objects.get(id=id)
    return render(request,'editregister.html',{'a':k,'b':'BCA'})
def bcdelete(request,id):
    k=bca.objects.get(id=id)
    if(k.issuebooks == 0):
        k.delete()
    else:
        return render(request,'delalert.html',{'a':k.issuebooks})
    return redirect('/list/')
def bbview(request,id):
    j=studentissue.objects.all()
    k=bba.objects.get(id=id)
    return render(request,'sdetails.html',{'a':k,'b':'BBA','c':j})
def bbed(request,id):
    k=bca.objects.get(id=id)
    return render(request,'editregister.html',{'a':k,'b':'BBA'})
def bbdelete(request,id):
    k=bba.objects.get(id=id)
    if(k.issuebooks == 0):
        k.delete()
    else:
        return render(request,'delalert.html',{'a':k.issuebooks})
    return redirect('/list/')
def bmview(request,id):
    j=studentissue.objects.all()
    k=bcom.objects.get(id=id)
    return render(request,'sdetails.html',{'a':k,'b':'BCOM','c':j})
def bmed(request,id):
    k=bcom.objects.get(id=id)
    return render(request,'editregister.html',{'a':k,'b':'BCOM'})
def bmdelete(request,id):
    k=bcom.objects.get(id=id)
    if(k.issuebooks == 0):
        k.delete()
    else:
        return render(request,'delalert.html',{'a':k.issuebooks})
    return redirect('/list/')
def mmview(request,id):
    j=studentissue.objects.all()
    k=mcom.objects.get(id=id)
    return render(request,'sdetails.html',{'a':k,'b':'MCOM','c':j})
def mmed(request,id):
    k=mcom.objects.get(id=id)
    return render(request,'editregister.html',{'a':k,'b':'MCOM'})
def mmdelete(request,id):
    k=mcom.objects.get(id=id)
    if(k.issuebooks == 0):
        k.delete()
    else:
        return render(request,'delalert.html',{'a':k.issuebooks})
    return redirect('/list/')
def techview(request,id):
    k=teachers.objects.get(id=id)
    j=teacherissue.objects.all() 
    return render(request,'tdetails.html',{'a':k,'b':j})
def teched(request,id):
    k=teachers.objects.get(id=id)
    return render(request,'editregister.html',{'c':k})
def techdelete(request,id):
    k=teachers.objects.get(id=id)
    k.delete()  
    return redirect('/list/')
def option(request):
    if(request.method == 'POST'):
        opt=request.POST.get('opt')
        mem=request.POST.get('mem')
        if(opt == 'issue' or opt == 'return'):
            if(mem == 'student'):
              return render(request,'issue.html')
            elif(mem == 'teacher'):
                return render(request,'issuet.html')
        elif(opt == 'record'):
            if(mem == 'student'):
                a=studentissue.objects.all()
                b=0
                return render(request,'retlist.html',{'k':a,'f':b})
            elif(mem == 'teacher'):
                a=teacherissue.objects.all()
                b=0
                return render(request,'retlistt.html',{'k':a,'f':b})
def check(request):
    if(request.method == 'POST'):
        accno=request.POST.get('accno')
        a=books.objects.get(accno = accno)
        department=request.POST.get('department')
        rollnumber=request.POST.get('rollnumber')
        if(department == 'BBA'):
            b=bba.objects.get(rollnumber = rollnumber)
        if(department == 'BCA'):
            b=bca.objects.get(rollnumber = rollnumber)
        if(department == 'BCOM'):
            b=bcom.objects.get(rollnumber = rollnumber)
        if(department == 'MCOM'):
            b=mcom.objects.get(rollnumber = rollnumber)
        if(a.issued == 'AVILABLE'):
            d=date.today()
            d1=d+timedelta(7)
            print(d1)
            return render(request,'postissue.html',{'k':a,'td':d,'rt':d1,'l':b,'dp':department})
        else:
            return render(request,'bookalert.html')
def tcheck(request):
    if(request.method == 'POST'):
        accno=request.POST.get('accno')
        a=books.objects.get(accno = accno)
        if(a.issued == 'AVILABLE'):
            d=date.today()
            d1=d+timedelta(7)
            print(d1)
            return render(request,'postissuet.html',{'k':a,'td':d,'rt':d1})
        else:
            return render(request,'bookalert.html')
def retustud(request):
    if(request.method == 'POST'):
        id=request.POST.get('id')
        a=studentissue.objects.get(id=id)
        d=date.today()
        print (d)
        f=d-a.duedate
        due = int(f/timedelta(1))
        if(due>0):
            fn=due*2
        else:
            fn=0    
        return render(request,'return.html',{'k':a,'rt':d,'fine':fn})
def stissue(request):
    if(request.method == 'POST'):
        department=request.POST.get('department')
        batch=request.POST.get('batch')
        rollnumber=request.POST.get('rollnumber')
        if(department == 'BCA'):
            b=bca.objects.get(rollnumber = rollnumber)
            if(b.issuebooks == 3):
                return redirect('/isret/')
            else:
                b.issuebooks=b.issuebooks+1
                b.save()
        if(department == 'BBA'):
            b=bba.objects.get(rollnumber = rollnumber)
            if(b.issuebooks == 3):
                return redirect('/isret/')
            else:
                b.issuebooks=b.issuebooks+1
                b.save()
        if(department == 'BCOM'):
            b=bcom.objects.get(rollnumber = rollnumber)
            if(b.issuebooks == 3):
                return redirect('/isret/')
            else:
                b.issuebooks=b.issuebooks+1
                b.save()
        if(department == 'MCOM'):
            b=mcom.objects.get(rollnumber = rollnumber)
            if(b.issuebooks == 3):
                return redirect('/isret/')
            else:
                b.issuebooks=b.issuebooks+1
                b.save()
        accno=request.POST.get('accno')
        g=books.objects.get(accno = accno)
        g.issued='NOT AVILABLE'
        g.issuemember='studentissue'
        g.save()
        a=studentissue()
        a.accno=accno
        a.title=request.POST.get('title')
        a.author=request.POST.get('author')
        a.edition=request.POST.get('edition')
        a.studentname=request.POST.get('studentname')
        a.rollnumber=request.POST.get('rollnumber')
        a.batch=request.POST.get('batch')
        a.department=request.POST.get('department')
        a.flag=0
        i=date.today()
        d=request.POST.get('duedate')
        a.issuedate = i
        a.duedate = i+timedelta(7)
        a.save()
        accno=request.POST.get('accno')
        e=studentissue.objects.get(accno=accno,flag=0)
        return render(request,'issuealert.html',{'k':e,'p':accno})

def sret(request,id):
    if(request.method == 'POST'):
        a=studentissue.objects.get(id=id)
        d=request.POST.get('returndate')
        a.returndate= date.today()
        a.flag=1
        a.save()
        department=request.POST.get("department")
        rollnumber=request.POST.get('rollnumber')
        if(department == 'BCA'):
            b=bca.objects.get(rollnumber=rollnumber)
            b.issuebooks=b.issuebooks-1
            b.save()
        if(department == 'BBA'):
            b=bba.objects.get(rollnumber=rollnumber)
            b.issuebooks=b.issuebooks-1
            b.save()
        if(department == 'BCOM'):
            b=bcom.objects.get(rollnumber=rollnumber)
            b.issuebooks=b.issuebooks-1
            b.save()
        if(department == 'MCOM'):
            b=mcom.objects.get(rollnumber=rollnumber)
            b.issuebooks=b.issuebooks-1
            b.save()
        accno=request.POST.get('accno')
        c=books.objects.get(accno=accno)
        c.issued='AVILABLE'
        c.issuemember='NULL'
        c.save()
        return render(request,'returnalert.html')
def teissue(request):
    if(request.method == 'POST'):
        a=teacherissue()    
        a.accno=request.POST.get('accno')
        a.title=request.POST.get('title')
        a.author=request.POST.get('author')
        a.edition=request.POST.get('edition')
        a.teachername=request.POST.get('name')
        a.staffnumber=request.POST.get('stnumber')
        a.department=request.POST.get('department')
        a.flag=0
        i=date.today()
        a.issuedate = i
        a.save()
        stnumber=request.POST.get('stnumber')
        b=teachers.objects.get(stnumber=stnumber)
        b.issuebooks=b.issuebooks+1
        b.save()
        accno=request.POST.get('accno')
        c=books.objects.get(accno=accno)
        c.issued='NOT AVILABLE'
        c.issuemember='teacherissue'
        c.save()
        accno=request.POST.get('accno')
        e=teacherissue.objects.get(accno=accno,flag=0)
        return render(request,'issuealert.html',{'k':e,'p':accno})
        
def rettec(request):
    if(request.method == 'POST'):
        id=request.POST.get('id')
        a=teacherissue.objects.get(id=id)
        d=date.today()
        return render(request,'returnt.html',{'k':a,'rt':d})
def tret(request,id):
    if(request.method == 'POST'):
        a=teacherissue.objects.get(id=id)
        d=request.POST.get('returndate')
        a.returndate= date.today()
        a.flag=1
        a.save()
        department=request.POST.get("deparment")
        stnumber=request.POST.get('stnumber')
        b=teachers.objects.get(stnumber=stnumber)
        b.issuebooks=b.issuebooks-1
        b.save()
        accno=request.POST.get('accno')
        c=books.objects.get(accno=accno)
        c.issued='AVILABLE'
        c.issuemember='NULL'
        c.save()
        return render(request,'issue.html')
def dele(request):
     if(request.method == 'POST'):
        department=request.POST.get('department')
        batch=request.POST.get('batch')
        if(department == 'BCA'):
            b=bca.objects.all()
            for i in b:
                if(i.batch == batch and i.issuebooks == '0'):
                    i.delete()
        if(department == 'BBA'):
            b=bba.objects.all()
            for i in b:
                if(i.batch == batch and i.issuebooks == '0'):
                    i.delete()
        if(department == 'BCOM'):
            b=bcom.objects.all()
            for i in b:
                if(i.batch == batch and i.issuebooks == '0'):
                    i.delete()
        if(department == 'MCOM'):
            b=mcom.objects.all()
            for i in b:
                if(i.batch == batch and i.issuebooks == '0'):
                    i.delete()
        return render(request,'delete.html')
def bl(request):
    if(request.method == 'POST'):
        department=request.POST.get('department')
        batch=request.POST.get('batch')
        if(department == 'BCA'):
            b=bca.objects.all()
            return render(request,'printlist.html',{'a':b,'c':batch,'d':department})
        if(department == 'BBA'):
            b=bba.objects.all()
            return render(request,'printlist.html',{'a':b,'c':batch,'d':department})        
        if(department == 'BCOM'):
            b=bcom.objects.all()
            return render(request,'printlist.html',{'a':b,'c':batch,'d':department})
        if(department == 'MCOM'):
            b=mcom.objects.all()
            return render(request,'printlist.html',{'a':b,'c':batch,'d':department})

    
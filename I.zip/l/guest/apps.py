from django.apps import AppConfig


class GuestConfig(AppConfig):
    name = 'guest'

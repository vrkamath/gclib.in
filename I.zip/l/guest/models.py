from django.db import models

# Create your models here.
class uslogin(models.Model):
    username=models.CharField(max_length=16)
    password=models.CharField(max_length=16)
    datetime=models.CharField(max_length=20)
    dept=models.CharField(max_length=5)
    usertype=models.CharField(max_length=10)
from django.shortcuts import render
from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import AnonymousUser
from books.models import login,bba,bcom,bca,teachers,books,mcom,studentissue,teacherissue
from django.http import HttpResponse
from datetime import *
from tkinter import messagebox
# Create your views here.
def index(request):
    return render(request,'index.html')
def g(request):
    a=books.objects.all().count()
    return render(request,'homeg.html',{'l':a})
def search(request):
    if(request.method == 'POST'):
        ser=request.POST.get('ser')
        if(ser.isnumeric()):
            a=books.objects.get(accno=ser)
            return render(request,'result1.html',{'k':a})
        else:
            i=books.objects.all()
            return render(request,'result2.html',{'k':i,'s':ser.upper(),'f':0})






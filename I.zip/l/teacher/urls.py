from django.urls import path
from . import views
urlpatterns = [
    path('homet/',views.homet),
    path('tbokl/',views.tbokl),
    path('tview/<int:id>',views.tview),
    path('tmembers/',views.tmembers),
    path('tteachlist/',views.tteachlist),
    path('tbcalist/',views.tbcalist),
    path('tbbalist/',views.tbbalist),
    path('tbcomlist/',views.tbcomlist),
    path('tmcomlist/',views.tmcomlist),            
    path('tbcview/<int:id>',views.tbcview),
    path('tbbview/<int:id>',views.tbbview),
    path('tbmview/<int:id>',views.tbmview),
    path('tmmview/<int:id>',views.tmmview),
    path('ttview/<int:id>',views.ttview),
    path('treturnl/',views.treturnl),
    path('trecord/',views.trecord),
    path('srecord/',views.srecord),    
]
from django.shortcuts import render
from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import AnonymousUser
from books.models import login,bba,bcom,bca,teachers,books,mcom,studentissue,teacherissue
from django.http import HttpResponse
from datetime import *
from tkinter import messagebox
# Create your views here.
def homet(request):
    return render(request,'homet.html')
def tbokl(request):
    k=books.objects.all()
    return render(request,'tbokl.html',{'a':k})
def tview(request,id):
    k=books.objects.get(id=id)
    if(k.issuemember == 'studentissue'):
        t=studentissue.objects.get(accno=k.accno,flag='0')
        j='studentissue'
    if(k.issuemember == 'teacherissue'):
        t=teacherissue.objects.get(accno=k.accno,flag='0')
        j='teacherissue'
    else:
        t='none'
    return render(request,'tview.html',{'a':k,'b':t,})
def tmembers(request):
    b=bca.objects.all().count()
    c=bba.objects.all().count()
    d=bcom.objects.all().count()
    e=mcom.objects.all().count()
    t=teachers.objects.all().count()
    f=b+c+d+e+t
    return render(request,'tmembers.html',{'te':t,'bc':b,'bb':c,'bo':d,'mo':e})
def tteachlist(request):
    h=teachers.objects.all()
    return render(request,'tteacherlist.html',{'a':h})
def tbcalist(request):
    h=bca.objects.all()
    return render(request,'tbcalist.html',{'a':h})
def tbbalist(request):
    h=bba.objects.all()
    return render(request,'tbbalist.html',{'a':h})
def tbcomlist(request):
    h=bcom.objects.all()
    return render(request,'tbcomlist.html',{'a':h})
def tmcomlist(request):
    h=mcom.objects.all()
    return render(request,'tmcomlist.html',{'a':h})
def ttview(request,id):
    k=teachers.objects.get(id=id)
    l=teacherissue.objects.all()
    return render(request,'ttdetails.html',{'a':k,'b':l})
def tbcview(request,id):
    j=studentissue.objects.all()
    k=bca.objects.get(id=id)
    return render(request,'tsdetails.html',{'a':k,'b':'BCA','c':j})
def tbbview(request,id):
    j=studentissue.objects.all()
    k=bba.objects.get(id=id)
    return render(request,'tsdetails.html',{'a':k,'b':'BBA','c':j})
def tbmview(request,id):
    j=studentissue.objects.all()
    k=bcom.objects.get(id=id)
    return render(request,'tsdetails.html',{'a':k,'b':'BCOM','c':j})
def tmmview(request,id):
    j=studentissue.objects.all()
    k=mcom.objects.get(id=id)
    return render(request,'tsdetails.html',{'a':k,'b':'MCOM','c':j})
def treturnl(request):
    k=teachers.objects.all()
    l=teacherissue.objects.all()
    return render(request,'treturnl.html',{'i':k,'b':l})
def trecord(request):
    a=teacherissue.objects.all()
    return render(request,'trecord.html',{'k':a})
def srecord(request):
    a=studentissue.objects.all()
    return render(request,'srecord.html',{'k':a})

